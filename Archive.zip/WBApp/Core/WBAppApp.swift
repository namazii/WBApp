//
//  WBAppApp.swift
//  WBApp
//
//  Created by Назар Ткаченко on 05.06.2024.
//

import SwiftUI

@main
struct WBAppApp: App {
    var body: some Scene {
        WindowGroup {
            OnboardingView()
        }
    }
}
